from main import evaluate


evaluate('../annotations/test_annotations_devsplit.json',
         'submission.zip',
         phase_codename='test')

evaluate('../annotations/test_annotations_devsplit.json',
         'submission_h5.zip',
         phase_codename='test')

evaluate('../annotations/test_annotations_devsplit.json',
         'submission_csv.zip',
         phase_codename='test')
